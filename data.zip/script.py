import os

def run():
    # run matmul3 4096 16 and save output to matmul3_4096_16.txt
    dim_val = [1024, 2048, 4096]
    block_val = [128]
    for question in range(3, 4):
        for dim in dim_val:
            if question == 3:
                for block in block_val:
                    os.system("./bin/matmul" + str(question) + " " + str(dim) + " " + str(block) + " > matmul" + str(question) + "_" + str(dim) + "_" + str(block) + ".txt")
            else:
                os.system("./bin/matmul" + str(question) + " " + str(dim) + " > matmul" + str(question) + "_" + str(dim) + "_" + ".txt")


if __name__ == "__main__":
    run()